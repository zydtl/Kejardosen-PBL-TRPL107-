<?php $__env->startSection('title'); ?>
    Dashboard - Mahasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/Dashboard-mahasiswa.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="left">
        <div class="card-welcome">
            <div class="text">
                <h1>Halo!👋</h1>
                <div class="nama"><?php echo e($mahasiswa->nama_mahasiswa); ?></div>
                <div class="slogan">🎯Bimbingan on time, Tugas Akhir on point!</div>
                <a href="<?php echo e(route('mahasiswa.pengajuan')); ?>">
                    <button  class="ajukan"><h3>Ajukan Jadwal</h3><i class="fi fi-br-calendar"></i></button>
                </a>
            </div>
            <img class="img-welcome-mahasiswa" src="<?php echo e(asset('assets/dashboard/asset/img/student_ilustration.png')); ?>" alt="" />
        </div>

        <div class="progress-container">
            <div class="progress-header">
                <div class="progress-title">
                    <i class="fi fi-br-chart"></i>
                    <span>Progres TA</span>
                </div>
                <?php if(!empty($logbook->kodeLogbook)): ?>
                    <a href="<?php echo e(route('mahasiswa.form-logbook', ['kodeLogbook' => $logbook->kodeLogbook])); ?>">
                        <button class="edit-button">
                            <i class="fi fi-br-edit"></i>
                            Edit Progres
                        </button>
                    </a>
                <?php else: ?>
                <a href="<?php echo e(route('mahasiswa.logbook')); ?>">
                    <button class="edit-button">
                        <i class="fi fi-br-edit"></i>
                        Edit Progres
                    </button>
                </a>
                <?php endif; ?>
            </div>
            <div class="progress-bar">
                
                    <?php if(!empty($logbook->progres)): ?>
                        <div class="progress-fill" style="width: <?php echo e($logbook->progres > 0 ? $logbook->progres : 100); ?>%;">
                    <?php else: ?>
                        <div class="progress-fill-kosong" style="width:100%">
                    <?php endif; ?>


                    <?php if(!empty($logbook->progres)): ?>
                        <span class="progress-text"><?php echo e($logbook->progres); ?>%</span>
                    <?php else: ?>
                        <span class="progress-text">Logbook masih kosong</span>
                    <?php endif; ?>
                </div>                
            </div>
        </div>

        <div class="card-jadwal-dosen">
            <div class="weekly-schedule">
                <i class="fi fi-br-calendar"></i>
                <h3>Jadwal Dosen Pembimbing</h3>
            </div>
            <div class="profile">
                <img src="<?php echo e(asset('assets/dashboard/asset/img/avatar-dosen.png')); ?>">
                <div class="profile-details">
                    <h4><?php echo e($mahasiswa->dosen->nama_dosen); ?></h4>
                    <span>NIK : <?php echo e($mahasiswa->nik_dosen); ?></span>
                    <div class="button-container">
                        <a href="<?php echo e(route('mahasiswa.waktu-dosen')); ?>">Selengkapnya</a>
                    </div>
                </div>
            </div>
            <div class="schedule">
                <div class="day <?php echo e($waktuDosen->kondisi_senin == 0 ? 'disabled' : ''); ?>">Sen</div>
                <div class="day <?php echo e($waktuDosen->kondisi_selasa == 0 ? 'disabled' : ''); ?>">Sel</div>
                <div class="day <?php echo e($waktuDosen->kondisi_rabu == 0 ? 'disabled' : ''); ?>">Rab</div>
                <div class="day <?php echo e($waktuDosen->kondisi_kamis == 0 ? 'disabled' : ''); ?>">Kam</div>
                <div class="day <?php echo e($waktuDosen->kondisi_jumat == 0 ? 'disabled' : ''); ?>">Jum</div>
                <div class="day <?php echo e($waktuDosen->kondisi_sabtu == 0 ? 'disabled' : ''); ?>">Sab</div>
                <div class="day <?php echo e($waktuDosen->kondisi_minggu == 0 ? 'disabled' : ''); ?>">Min</div>
            </div>
                        
        </div>
        <div class="spacer"></div>
    </div>
    <div class="right">

        <h2 class="notif">🔔 Pemberitahuan</h2>

        <?php if($notifications->isEmpty()): ?>
            <div class="notif-item">
                <div class="notif-icon gray">
                    <i class="fi fi-br-bell-slash"></i>
                </div>
                <div class="notif-text">
                    <h4>Tidak Ada Notifikasi</h4>
                    <p>Anda tidak memiliki notifikasi dalam 7 hari terakhir.</p>
                </div>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="notif-item">
                    <div class="notif-icon 
                        <?php if($notification['type'] === 'Pengajuan Disetujui'): ?> blue 
                        <?php elseif($notification['type'] === 'Pengajuan Ditolak'): ?> red
                        <?php elseif($notification['type'] === 'Pengajuan Alternatif'): ?> yellow
                        <?php elseif($notification['type'] === 'Bimbingan Dibatalkan'): ?> red
                        <?php elseif($notification['type'] === 'Jadwal Diperbarui'): ?> yellow
                        <?php elseif($notification['type'] === 'Pengingat Logbook'): ?> blue
                        <?php elseif($notification['type'] === 'Logbook Ditanggapi'): ?> blue
                        <?php else: ?> gray <?php endif; ?>
                    ">
                        <i class="fi 
                            <?php if($notification['type'] === 'Pengajuan Disetujui'): ?> fi-br-graduation-cap
                            <?php elseif($notification['type'] === 'Pengajuan Ditolak'): ?> fi-br-graduation-cap
                            <?php elseif($notification['type'] === 'Pengajuan Alternatif'): ?> fi-br-graduation-cap
                            <?php elseif($notification['type'] === 'Bimbingan Dibatalkan'): ?> fi-br-calendar
                            <?php elseif($notification['type'] === 'Jadwal Diperbarui'): ?> fi-br-calendar
                            <?php elseif($notification['type'] === 'Pengingat Logbook'): ?> fi-br-memo
                            <?php elseif($notification['type'] === 'Logbook Ditanggapi'): ?> fi-br-memo
                            <?php else: ?> fi-br-bell-slash <?php endif; ?>
                        "></i>
                    </div>
                    <div class="notif-text">
                        <h4><?php echo e($notification['type']); ?></h4>
                        <p><?php echo e($notification['description']); ?></p>
                        <small class="date-text-notif" ><?php echo e(\Carbon\Carbon::parse($notification['updated_at'])->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y - H:i')); ?> WIB</small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        

        


        <h2>📅 Jadwal Bimbingan</h2>
        <?php if($jadwal->isNotEmpty()): ?>
            <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bimbingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-pengajuan">
                    <a  href="<?php echo e(route('mahasiswa.detail-jadwal-bimbingan', ['kodeJadwal' => $bimbingan->kodeJadwal])); ?>">
                        <div class="detail1">
                            <div><img src="<?php echo e(asset('assets/dashboard/asset/img/avatar-dosen.png')); ?>" alt="" /></div>
                            <div class="value">
                                <h4 class="dosen"><?php echo e($bimbingan->pengajuan->mahasiswa->dosen->nama_dosen); ?></h4>
                                <div class="tanggal"><i class="fi fi-br-calendar"></i><?php echo e(\Carbon\Carbon::parse($bimbingan->tanggal_bimbingan)->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y')); ?></div>
                                <div class="jam"><i class="fi fi-br-clock"></i><?php echo e(\Carbon\Carbon::parse($bimbingan->waktu_bimbingan)->format('H:i')); ?> WIB</div>
                            </div>
                        </div>
                    
                        <div class="detail2">
                            <div class="item">
                                <i class="fi fi-br-map-marker-home"></i>
                                <p>Ruangan</p>
                                <span><?php echo e(strlen($bimbingan->tempat) > 24 ? 'Lihat selengkapnya  ➡️' : ($bimbingan->tempat ?? 'Tidak ada')); ?></span>
                            </div>
                            <div class="item">
                                <i class="fi fi-br-time-add"></i>
                                <p>Dibuat</p>
                                <span><?php echo e(\Carbon\Carbon::parse($bimbingan->created_at)->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y')); ?></span>
                            </div>
                            <div class="item">
                                <i class="fi fi-br-memo"></i>
                                <p>Kode Pengajuan</p>
                                <span><?php echo e($bimbingan->pengajuan->kodePengajuan ?? 'N/A'); ?>   </span>
                            </div>
                            <div class="item">
                                <i class="fi fi-br-memo"></i>
                                <p>Kode Jadwal</p>
                                <span><?php echo e($bimbingan->kodeJadwal ?? 'N/A'); ?> </span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <img class="bimbingan-kosong" src="<?php echo e(asset('assets/dashboard/asset/img/bimbingan_kosong_mhs.svg')); ?>" alt="">
        <?php endif; ?>

        <div class="spacer"></div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.mahasiswa.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/mahasiswa/dashboard.blade.php ENDPATH**/ ?>