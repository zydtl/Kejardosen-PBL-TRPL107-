<?php $__env->startSection('title'); ?>
    Profil - Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/profil.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="title">
            <h1>Profil Saya</h1>
        </div>
        <div class="profil">
            <div class="foto">
                <img class="foto-profil" src="<?php echo e(asset('assets/dashboard/asset/img/avatar-dosen.png')); ?>" alt="" />
            </div>
            <div class="identitas">
                <div class="title-identitas">
                    <h3>Informasi Pribadi</h3>
                </div>
                <div class="isi-identitas">
                    <div class="row">
                        <div class="left-column">
                            <div class="ket">Nama</div>
                            <div class="value"><?php echo e($dosen->nama_dosen); ?></div>

                            <div class="ket">NIK/NIDN</div>
                            <div class="value"><?php echo e($dosen->nik); ?></div>

                            <div class="ket">Jumlah Mahasiswa</div>
                            <?php if($mahasiswa > 0): ?>
                                <div class="value"><?php echo e($mahasiswa); ?> Orang Mahasiswa</div>
                            <?php else: ?>
                                <div class="value">⛔Belum memiliki mahasiswa</div>
                            <?php endif; ?>
                        </div>
                        <div class="right-column">
                            <div class="ket">Email</div>
                            <div class="value"><?php echo e($dosen->email); ?></div>

                            <div class="ket">Jenis Kelamin</div>
                            <div class="value"><?php echo e($dosen->jenis_kelamin); ?></div>

                            <div class="ket">No Telp</div>
                            <div class="value"><?php echo e($dosen->no_telp); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/info.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/profile.blade.php ENDPATH**/ ?>