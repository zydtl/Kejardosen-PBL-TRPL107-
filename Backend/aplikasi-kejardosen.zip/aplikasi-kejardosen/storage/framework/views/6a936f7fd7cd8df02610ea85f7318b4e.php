<?php $__env->startSection('title'); ?>
    Waktu Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/waktu-dosen.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="title">
        <h1>Waktu Dosen</h1>
    </div>
    <div class="card-welcome">
        <div class="text">
            <h1>Atur jadwal bimbingan Anda</h1>
            <div class="slogan">Hari yang Anda pilih akan digunakan sebagai default untuk semua minggu kecuali Anda membuat perubahan.</div>
            <div class="contoh-warna">
                <div class="contoh-warna-aktif"></div> 
                <p>hari aktif</p>
                <div class="contoh-warna-tidak-aktif"></div>
                <p>hari tidak aktif</p>
            </div>
        </div>
        <img class="img-welcome-dosen" src="<?php echo e(asset('assets/dashboard/asset/img/pilih-waktu.svg')); ?>" alt="" />
    </div>
    <div class="card-hari">
        <div class="card-header">
            <div class="header-text">Jadwal Anda:</div>
            <button class="atur-jadwal-btn"
                data-id = "<?php echo e($waktuDosen->idWaktuDosen); ?>"
                data-kondisi_senin = "<?php echo e($waktuDosen->kondisi_senin); ?>"
                data-kondisi_selasa = "<?php echo e($waktuDosen->kondisi_selasa); ?>"
                data-kondisi_rabu = "<?php echo e($waktuDosen->kondisi_rabu); ?>"
                data-kondisi_kamis = "<?php echo e($waktuDosen->kondisi_kamis); ?>"
                data-kondisi_jumat = "<?php echo e($waktuDosen->kondisi_jumat); ?>"
                data-kondisi_sabtu = "<?php echo e($waktuDosen->kondisi_sabtu); ?>"
                data-kondisi_minggu = "<?php echo e($waktuDosen->kondisi_minggu); ?>"
            >Atur Jadwal</button>
        </div>
    
        <div class="hari <?php echo e($waktuDosen->kondisi_senin == 1 ? 'checked' : ''); ?>" id="kondisi-senin">
            <h3>Senin</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_selasa == 1 ? 'checked' : ''); ?>" id="kondisi-selasa">
            <h3>Selasa</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_rabu == 1 ? 'checked' : ''); ?>" id="kondisi-rabu">
            <h3>Rabu</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_kamis == 1 ? 'checked' : ''); ?>" id="kondisi-kamis">
            <h3>Kamis</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_jumat == 1 ? 'checked' : ''); ?>" id="kondisi-jumat">
            <h3>Jumat</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_sabtu == 1 ? 'checked' : ''); ?>" id="kondisi-sabtu">
            <h3>Sabtu</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_minggu == 1 ? 'checked' : ''); ?>" id="kondisi-minggu">
            <h3>Minggu</h3>
        </div>
    </div>            
</div>


<div class="modalAturHari hidden" id="modalAturHari">
<div class="modal-content">
    <h3>Atur Waktu</h3>
    <form id="form-atur-hari">
        <div class="atur-hari">
            <label for="senin">Senin:</label>
            <input type="checkbox" id="senin" name="senin" value="senin">
        </div>
        <div class="atur-hari">
            <label for="selasa">Selasa:</label>
            <input type="checkbox" id="selasa" name="selasa" value="selasa">
        </div>
        <div class="atur-hari">
            <label for="rabu">Rabu:</label>
            <input type="checkbox" id="rabu" name="rabu" value="rabu">
        </div>
        <div class="atur-hari">
            <label for="kamis">Kamis:</label>
            <input type="checkbox" id="kamis" name="kamis" value="kamis">
        </div>
        <div class="atur-hari">
            <label for="jumat">Jumat:</label>
            <input type="checkbox" id="jumat" name="jumat" value="jumat">
        </div>
        <div class="atur-hari">
            <label for="sabtu">Sabtu:</label>
            <input type="checkbox" id="sabtu" name="sabtu" value="sabtu">
        </div>
        <div class="atur-hari">
            <label for="minggu">Minggu:</label>
            <input type="checkbox" id="minggu" name="minggu" value="minggu">
        </div>
        <button type="button" id="btn-simpan">Simpan</button>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/waktu-dosen.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/waktu-dosen.blade.php ENDPATH**/ ?>