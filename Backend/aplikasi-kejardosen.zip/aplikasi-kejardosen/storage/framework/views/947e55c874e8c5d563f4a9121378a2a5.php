<?php $__env->startSection('title'); ?>
  Detail Riwayat Jadwal Bimbingan - Mahasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/info.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="title-and-button">
            <div class="title">
                <h1>Detail Jadwal Bimbingan</h1>
            </div>
            <a href="<?php echo e(route('mahasiswa.riwayat-jadwal-bimbingan')); ?>" ><button class="btn btn-primary">Kembali</button></a>

        </div>
        <div class="card-header">
            <div class="img-header"> <img
                    src="<?php echo e(asset('assets/dashboard/asset/img/avatar-dosen.png')); ?>"alt="Profile Picture"
                    class="profile-pic"></div>
            <div class="text-header">
                <b>Kode Jadwal: <?php echo e($jadwal->kodeJadwal ?? '-'); ?></b><br>
                <small><b>Disepakati Pada:
                    </b><?php echo e(\Carbon\Carbon::parse($jadwal->created_at)->translatedFormat('l, d F Y')); ?> | <b>Jam :
                    </b><?php echo e(\Carbon\Carbon::parse($jadwal->created_at)->format('H:i')); ?> WIB</small>
                </small>
            </div>
            <div class="col col-5" data-label="Status"><span
                    class="
                        <?php if($jadwal->status == 'menunggu' || $jadwal->status == 'alternatif' || $jadwal->status == 'ditunda'): ?> status-waiting
                        <?php elseif($jadwal->status == 'dibatalkan' || $jadwal->status == 'ditolak'): ?> 
                            status-cancel
                        <?php elseif($jadwal->status == 'diterima'): ?> 
                            status-accept
                        <?php elseif($jadwal->status == 'berlangsung'): ?> 
                            status-ongoing
                        <?php elseif($jadwal->status == 'disetujui'): ?> 
                            status-accept                               
                        <?php elseif($jadwal->status == 'diselesaikan'): ?> 
                            status-finish <?php endif; ?>
                    "><?php echo e($jadwal->status); ?></span>
            </div>
        </div>
        <div class="detail-title">
            <h3>Detail Bimbingan</h3>
        </div>
        <div class="detail">
            <div class="ket">Nama Dosen Pembimbing</div>
            <div class="isi"><?php echo e($jadwal->pengajuan->mahasiswa->dosen->nama_dosen); ?></div>
        </div>
        <div class="detail">
            <div class="ket">NIK/NIDN</div>
            <div class="isi"><?php echo e($jadwal->pengajuan->mahasiswa->dosen->nik); ?></div>
        </div>
        <div class="detail">
            <div class="ket">Tanggal Kesepakatan</div>
            <div class="isi">
                📅<?php echo e(\Carbon\Carbon::parse($jadwal->pengajuan->tanggal_pengajuan)->translatedFormat('l, d F Y')); ?></div>
        </div>
        <div class="detail">
            <div class="ket">Waktu Kesepakatan</div>
            <div class="isi">⏰<?php echo e(\Carbon\Carbon::parse($jadwal->pengajuan->waktu_pengajuan)->format('H:i')); ?> WIB</div>
        </div>
        <div class="detail">
            <div class="ket">Tanggal Bimbingan</div>
            <div class="isi">
                📅<?php echo e($jadwal->tanggal_bimbingan ? \Carbon\Carbon::parse($jadwal->tanggal_bimbingan)->translatedFormat('l, d F Y') : '⛔ Tidak ada'); ?>

            </div>
        </div>
        <div class="detail">
            <div class="ket">Waktu Bimbingan</div>
            <div class="isi">
                ⏰<?php echo e($jadwal->waktu_bimbingan ? \Carbon\Carbon::parse($jadwal->waktu_bimbingan)->format('H:i') . ' WIB' : '⛔ Tidak ada'); ?>

            </div>
        </div>
        <div class="detail">
            <div class="ket">Jenis Bimbingan</div>
            <div class="isi">
                <?php if($jadwal->jenis_bimbingan === 'luring'): ?>
                    👩🏻‍🏫
                <?php elseif($jadwal->jenis_bimbingan === 'daring'): ?>
                    👨🏻‍💻
                <?php else: ?>
                    ⛔ Tidak ada
                <?php endif; ?>
                <?php echo e($jadwal->jenis_bimbingan ?? '⛔ Tidak ada'); ?>

            </div>
        </div>
        <div class="detail">
            <div class="ket">Ruangan</div>
            <div class="isi">📍<?php echo e($jadwal->tempat ?? '⛔ Tidak ada'); ?></div>
        </div>
        <div class="detail">
            <div class="ket">Judul Bimbingan</div>
            <div class="isi"><?php echo e($jadwal->pengajuan->judul_bimbingan ?? '⛔ Tidak ada'); ?></div>
        </div>
        <div class="detail">
            <div class="ket">Catatan Mahasiswa</div>
            <div class="isi">
                <?php if(!empty($jadwal->catatan_mahasiswa)): ?>
                    📝 <?php echo e($jadwal->catatan_mahasiswa); ?>

                <?php else: ?>
                    ⛔ Tidak ada
                <?php endif; ?>
            </div>
        </div>
        <div class="detail">
            <div class="ket">Catatan Dosen</div>
            <div class="isi">
                <?php if(!empty($jadwal->catatan_dosen)): ?>
                    📝 <?php echo e($jadwal->catatan_dosen); ?>

                <?php else: ?>
                    ⛔ Tidak ada
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.mahasiswa.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/mahasiswa/detail-riwayat-jadwal-bimbingan.blade.php ENDPATH**/ ?>