<?php $__env->startSection('title'); ?>
    Daftar Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content" >
        <div class="title"><h1>Daftar Dosen</h1></div>
        <div class="search-and-button">
            <div class="search-container">
                <input type="text" id="search-input" onkeyup="searchTable()" placeholder="Pencarian">
            </div> 
            <button id="tambah-dsn" class="btn btn-primary">Tambah Dosen</button>
        </div>
        
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">Nama Dosen</div>
                <div class="col col-2">NIK/NIDN</div>
                <div class="col col-3">Aksi</div>
            </li>
            <?php $__empty_1 = true; $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
            <li class="table-row">
                <div class="col col-1" data-label="Nama Dosen">
                    <?php echo e($data->nama_dosen); ?>

                </div>
                <div class="col col-2" data-label="NIK/NIDN">
                    <?php echo e($data->nik); ?>

                </div>
                    <div class="col col-3" data-label="Aksi">
                        <button id="info-dsn" class="btn-info-dsn" 
                            data-nik="<?php echo e($data->nik); ?>" 
                            data-nama="<?php echo e($data->nama_dosen); ?>" 
                            data-password="<?php echo e($data->password); ?>" 
                            data-jenis_kelamin="<?php echo e($data->jenis_kelamin); ?>" 
                            data-no_telp="<?php echo e($data->no_telp); ?>" 
                            data-email="<?php echo e($data->email); ?>"
                        ><i class="fi fi-br-info info"></i></button>
                        <button id="edit-dsn" class="btn-edit-dsn" 
                            data-nik="<?php echo e($data->nik); ?>" 
                            data-nama="<?php echo e($data->nama_dosen); ?>" 
                            data-password="<?php echo e($data->password); ?>" 
                            data-jenis_kelamin="<?php echo e($data->jenis_kelamin); ?>" 
                            data-no_telp="<?php echo e($data->no_telp); ?>" 
                            data-email="<?php echo e($data->email); ?>"
                        ><i class="fi fi-br-edit edit">
                        </i></button>
                        <button class="btn-hapus-dsn" 
                            <?php if($data->has_mahasiswa): ?> disabled style="
                                background-color: #dcdcdc; 
                                background-color: #dcdcdc; /* Warna latar belakang abu-abu */
                                color: #a9a9a9; /* Warna teks abu-abu */
                                cursor: not-allowed; /* Mengubah cursor menjadi tanda larangan */
                                border: 1px solid #dcdcdc; /* Menyesuaikan border */
                            " <?php endif; ?>
                        ><i class="fi fi-br-trash trash"></i></button>
                    </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="table-row gambar-kosong">
                    <div class="col" style="text-align: center; width: 100%;">
                        <img src="<?php echo e(asset('assets/dashboard/asset/img/tabel-kosong.svg')); ?>" alt="Kosong" />
                        <p>Belum ada dosen terdaftar...</p>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
        
        <!-- Pagination -->
        <div class="pagination">
            <button class="prev-page">Prev</button>
            <span class="page-numbers">
                <span class="page-number active">1</span>
                <span class="page-number">2</span>
                <span class="page-number">3</span>
                <!-- Tambahkan lebih banyak page number sesuai dengan jumlah data -->
            </span>
            <button class="next-page">Next</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modalAdmin'); ?>
    <!-- Modal Admin : Tambah Dosen -->
    <div id="formModalAdminDosen" class="hide">
        <div class="modal1">
            <h2>Tambah Data Dosen</h2>
            <form id="formDosen" action="<?php echo e(route('daftar-dosen.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- Container Utama -->
                <div class="form-container-dosen">
                    <!-- Form Input -->
                    <div class="form-group">
                        <label for="nama">Nama Dosen</label>
                        <input type="text" id="nama" class="form-control" placeholder="Masukkan nama dosen" required>
                    </div>

                    <div class="form-group">
                        <label for="nik">NIK/NIDN</label>
                        <input type="text" id="nik" class="form-control" placeholder="Masukkan NIK/NIDN dosen" required>
                    </div>

                    <div class="form-group">
                        <label for="jenisKelamin">Jenis Kelamin</label>
                        <select id="jenisKelamin" class="form-control" required>
                            <option value="" disabled selected>Pilih jenis kelamin</option>
                            <option value="Laki-laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="noTelp">Nomor Telepon</label>
                        <input type="text" id="noTelp" class="form-control" placeholder="Masukkan nomor telepon dosen" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" class="form-control" placeholder="Masukkan email dosen" required>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" id="password" class="form-control" placeholder="Masukkan password dosen" required>
                    </div>
                </div>

                <!-- Tombol Aksi -->
                <div class="button-group">
                    <button type="button" id="closeFormDosen" class="btn-batalkan btn-secondary">Batalkan</button>
                    <button type="submit" id="tambahdsn" class="btn-simpan btn-primary">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>


    <!-- Modal Admin : Info Dosen -->
    <div id="infoModalAdminDosen" class="hide">
        <div class="modal2">
            <h2>Informasi Dosen</h2>
            <div class="form-container">
                <!-- Kolom Informasi Dosen -->
                <div class="column">
                    <!-- Nama Dosen -->
                    <div class="form-group">
                        <label for="namaDosen">Nama Dosen</label>
                        <div id="nama" class="value">Dr. Ahmad Maulana</div>
                    </div>
                    
                    <!-- NIK/NIDN -->
                    <div class="form-group">
                        <label for="nik">NIK/NIDN</label>
                        <div id="nik" class="value">1234567890</div>
                    </div>
                    
                    <!-- Jenis Kelamin -->
                    <div class="form-group">
                        <label for="jenisKelamin">Jenis Kelamin</label>
                        <div id="jenisKelamin" class="value">Laki-Laki</div>
                    </div>
                </div>    
                <div class="column">
                    <!-- Nomor Telepon -->
                    <div class="form-group">
                        <label for="noTelp">Nomor Telepon</label>
                        <div id="noTelp" class="value">081234567890</div>
                    </div>
                    
                    <!-- Email -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <div id="email" class="value">ahmad.maulana@example.com</div>
                    </div>

                    <!-- Password -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div id="password" class="value">Password Dosen gak boleh diintip ya...🤗🤗🤗</div>
                    </div>
                </div>
            </div>

            <!-- Tombol Aksi -->
            <div class="button-group">
                <button id="closeInfoDosen" class="btn-batalkan btn-secondary">Tutup</button>
            </div>
        </div>
    </div>


    <!-- Modal Admin : edit Dosen -->
    <div id="editModalAdminDosen" class="hide">
        <div class="modal2">
            <h2>Edit Informasi Dosen</h2>
            <form id="formEditDosen" action="<?php echo e(route('daftar-dosen.update', ['nik' => ':nik'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Untuk metode PUT -->
    
                <!-- Input ID Dosen (Hidden) -->
                <input type="hidden" name="id" id="dosenId" value="">
    
                <!-- Nama Dosen -->
                <div class="form-group">
                    <label for="nama_edit">Nama Dosen</label>
                    <input type="text" name="nama_dosen" id="nama_edit" class="form-control" required>
                </div>
    
                <!-- NIK/NIDN -->
                <div class="form-group">
                    <label for="nik">NIK/NIDN</label>
                    <input type="text" name="nik_edit" id="nik_edit" class="form-control" required>
                </div>
    
                <!-- Jenis Kelamin -->
                <div class="form-group">
                    <label for="jenisKelamin_edit">Jenis Kelamin</label>
                    <select id="jenisKelamin_edit" class="form-control" required>
                        <option value="" disabled selected>Pilih jenis kelamin</option>
                        <option value="Laki-laki">Laki-Laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
    
                <!-- Nomor Telepon -->
                <div class="form-group">
                    <label for="no_telp_edit">Nomor Telepon</label>
                    <input type="text" name="no_telp" id="no_telp_edit" class="form-control" required>
                </div>
    
                <!-- Email -->
                <div class="form-group">
                    <label for="email_edit">Email</label>
                    <input type="email" name="email" id="email_edit" class="form-control" required>
                </div>
    
                <!-- Password -->
                <div class="form-group">
                    <label for="password_edit">Password (Opsional)</label>
                    <input type="text" placeholder="kosongkan input ini jikalau tidak ingin diubah 🤗🤗🤗" name="password" id="password_edit" class="form-control">
                </div>
    
                <!-- Tombol Aksi -->
                <div class="button-group">
                    <button type="submit" class="btn-save btn-primary">Simpan</button>
                    <button type="button" id="closeEditDosen" class="btn-batalkan btn-secondary">Batal</button>
                </div>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/daftar-dosen.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/admin/daftar-dosen.blade.php ENDPATH**/ ?>