<?php $__env->startSection('title'); ?>
    Jadwal Bimbingan - Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/Jadwal-bimbingan.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="title"><h1>Jadwal Bimbingan</h1></div>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">Nama Mahasiswa</div>
                <div class="col col-2">NIM</div>
                
                <div class="col col-3">Tanggal Bimbingan</div>
                <div class="col col-4">Waktu Bimbingan</div>
                <div class="col col-5">Status</div>
                <div class="col col-6">Aksi</div>
            </li>
            <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="table-row">
                <div class="col col-1" data-label="Kode Jadwal"><?php echo e($item->pengajuan->mahasiswa->nama_mahasiswa); ?></div>
                <div class="col col-2" data-label="NIM"><?php echo e($item->pengajuan->mahasiswa->nim); ?></div>
                
                <div class="col col-3" data-label="Tanggal Bimbingan"><?php echo e(\Carbon\Carbon::parse($item->tanggal_bimbingan)->translatedFormat('l, d F Y')); ?></div>
                <div class="col col-4" data-label="Waktu Bimbingan"><?php echo e(\Carbon\Carbon::parse($item->waktu_bimbingan)->timezone('Asia/Jakarta')->format('H:i')); ?> WIB</div>
                <div class="col col-5" data-label="Status"><span class="
                                <?php if($item->status == 'menunggu' || $item->status == 'alternatif' || $item->status == 'ditunda'): ?>
                                    status-waiting
                                <?php elseif($item->status == 'dibatalkan' || $item->status == 'ditolak'): ?> 
                                    status-cancel
                                <?php elseif($item->status == 'diterima'): ?> 
                                    status-accept
                                <?php elseif($item->status == 'berlangsung'): ?> 
                                    status-ongoing
                                <?php elseif($item->status == 'disetujui'): ?> 
                                    status-accept                               
                                <?php elseif($item->status == 'diselesaikan'): ?> 
                                    status-finish 
                                <?php endif; ?>
                    "><?php echo e($item->status); ?></span></div>
                <!-- <div class="col col-5" data-label="Status"><span class="status-cancel">Dibatalkan</span></div> -->
                <!-- <div class="col col-5" data-label="Status"><span class="status-delay">Ditunda</span></div> -->
                <!-- <div class="col col-5" data-label="Status"><span class="status-finish">Selesai</span></div> -->
                <div class="col col-6" data-label="Aksi">
                    <button class="btn-tolak" title="Batalkan" data-role="dosen" data-kode="<?php echo e($item->kodeJadwal); ?>"><i class="fi fi-br-ban delete"></i></button>
                    <a href="<?php echo e(route('dosen.detail-jadwal-bimbingan', ['kodeJadwal' => $item->kodeJadwal])); ?>">
                        <button class="btn-info" title="Info">
                            <i class="fi fi-br-info info"></i>
                        </button>
                    </a>
                    <button class="btn-tunda" title="Tunda" 

                        data-kode="<?php echo e($item->kodeJadwal); ?>"
                        data-tanggal_bimbingan="<?php echo e($item->tanggal_bimbingan); ?>"
                        data-waktu_bimbingan="<?php echo e($item->waktu_bimbingan); ?>"


                        data-tanggal_pengajuan="<?php echo e(\Carbon\Carbon::parse($item->pengajuan->tanggal_pengajuan)->locale('id')->translatedFormat('d F Y')); ?>"
                        data-waktu_pengajuan="<?php echo e(\Carbon\Carbon::parse($item->pengajuan->waktu_pengajuan)->timezone('Asia/Jakarta')->format('H:i')); ?> WIB"
        
                        data-catatan_dosen="<?php echo e($item->catatan_dosen); ?>"
                        
                    ><i class="fi fi-br-pending delay"></i></button> 
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="table-row gambar-kosong">
                    <div class="col" style="text-align: center; width: 100%;">
                        <img src="<?php echo e(asset('assets/dashboard/asset/img/tabel-kosong.svg')); ?>" alt="Kosong" />
                        <p>Belum ada jadwal bimbingan.</p>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div id="formTundaDosen" class="modal-tunda hidden">
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <button class="close-modal" title="Tutup">&times;</button>
            <h2>Penundaan Jadwal Bimbingan</h2>
            <div class="waktu-bimbingan-before">
                <div class="datetime">
                    <div class="detail-group">
                        <div class="detail">
                            <label>Tanggal Bimbingan</label>
                            <div class="value disabled-input" id="tanggal_pengajuan">12 September 2024</div>
                        </div>
                        <div class="detail">
                            <label>Waktu Bimbingan</label>
                            <div class="value disabled-input" id="waktu_pengajuan">09:00 WIB</div>
                        </div>
                    </div>
                </div>
            </div>
            <form action="/" id="tunda" class="form-aksi">
                <div class="form-group">
                    <label for="tanggal-anjuran">Tanggal Penundaan</label>
                    <input type="date" id="tanggal-tunda" class="form-control" required />
                </div>
                <div class="form-group">
                    <label for="waktu-anjuran">Waktu Penundaan</label>
                    <input type="time" id="waktu-tunda" class="form-control" required />
                </div>
                <div class="form-group">
                    <label for="catatan-tunda">Catatan Dosen</label>
                    <textarea id="catatan-tunda" class="form-control" rows="4"
                        placeholder="Tambahkan catatan untuk mahasiswa" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-submit-tunda">Kirim</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/range-tunda.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/Jadwal-bimbingan-dsn.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/jadwal-bimbingan.blade.php ENDPATH**/ ?>