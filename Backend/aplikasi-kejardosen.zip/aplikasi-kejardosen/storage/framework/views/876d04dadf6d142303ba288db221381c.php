<?php $__env->startSection('title'); ?>
    Dashboard - Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/Dashboard-admin.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="left">
            <div class="card-welcome">
                <div class="text">
                    <h1>Halo!👋</h1>
                    <div class="nama">Username : <?php echo e($admin->username); ?> <span>(<?php echo e($admin->nama); ?>)</span></div>
                    <div class="slogan">Kontrol Penuh, Proses Lancar</div>
                </div>
                <img class="img-welcome-admin" src="<?php echo e(asset('assets/dashboard/asset/img/admin_ilustration.png')); ?>" alt="" />
            </div>

            <div class="info-cards">
                <div class="card-info">
                    <div class="card-info-icon">
                        <i class="fi fi-br-time-check"></i>
                    </div>
                    <div class="card-info-details">
                        <?php if($mahasiswa > 0): ?>
                            <h4>0<?php echo e($mahasiswa); ?></h4>
                        <?php else: ?>
                            <h4>00</h4>
                        <?php endif; ?>
                        <span>Mahasiswa</span>
                    </div>
                </div>
                <div class="card-info">
                    <div class="card-info-icon">
                        <i class="fi fi-br-duration-alt"></i>
                    </div>
                    <div class="card-info-details">
                        <?php if($dosen > 0): ?>
                            <h4>0<?php echo e($dosen); ?></h4>
                        <?php else: ?>
                            <h4>00</h4>
                        <?php endif; ?>
                        <span>Dosen Pembimbing</span>
                    </div>
                </div>
                <div class="card-info">
                    <div class="card-info-icon">
                        <i class="fi fi-br-time-check"></i>
                    </div>
                    <div class="card-info-details">
                        <?php if($jadwal > 0): ?>
                            <h4>0<?php echo e($jadwal); ?></h4>
                        <?php else: ?>
                            <h4>00</h4>
                        <?php endif; ?>
                        <span>Jumlah Bimbingan Aktif</span>
                    </div>
                </div>
            </div>
            <div class="spacer"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/admin/dashboard.blade.php ENDPATH**/ ?>