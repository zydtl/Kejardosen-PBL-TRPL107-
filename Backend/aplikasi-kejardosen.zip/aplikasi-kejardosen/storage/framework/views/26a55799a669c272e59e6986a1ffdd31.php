<?php $__env->startSection('title'); ?>
    Logbook - Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/logbook.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content" >
                        
        <div class="title"><h1>Logbook</h1></div>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">NIM</div>
                <div class="col col-2">Nama</div>
                <div class="col col-3">Terakhir Diubah</div>
                <div class="col col-4">Progres TA</div>
                <div class="col col-5">Aksi</div>
            </li>
            <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="table-row">
                <div class="col col-1" data-label="NIM"><?php echo e($item->nim); ?></div>
                <div class="col col-2" data-label="Nama"><?php echo e($item->nama_mahasiswa); ?></div>
                <div class="col col-3" data-label="Terakhir Diubah">

                <?php
                    $lastLogbook = $item->pengajuan->flatMap->jadwal->flatMap->logbooks->last();
                ?>

                <?php if($lastLogbook): ?>
                    <?php echo e(\Carbon\Carbon::parse($lastLogbook->created_at)->translatedFormat('l, d F Y - H:i')); ?> WIB
                <?php else: ?>
                    -
                <?php endif; ?>
    
                </div>
                <div class="col col-4" data-label="Progres TA">
                    <?php if($lastLogbook): ?>
                        <?php echo e($lastLogbook->progres); ?>%
                    <?php else: ?>
                        0%
                    <?php endif; ?>
                </div>
                <div class="col col-5" data-label="Aksi">
                    <a href="<?php echo e(route('dosen.daftar-logbook', ['nim' => $item->nim])); ?>">
                        <button class="btn-list"><i class="fi fi-br-list list"></i></button>
                    </a>
                    <button class="btn-profil" 
                    data-nama = "<?php echo e($item->nama_mahasiswa); ?>"
                    data-nim = "<?php echo e($item->nim); ?>"
                    data-email = "<?php echo e($item->email); ?>"
                    data-no_telp= "<?php echo e($item->no_telp); ?>"
                    data-judul_tugas_akhir = "<?php echo e($item->judul_tugas_akhir); ?>"
                    data-jenis_kelamin = "<?php echo e($item->jenis_kelamin); ?>"
                    data-kelas = "<?php echo e($item->kelas); ?>"
                    ><i class="fi fi-br-user profil"></i></button>
                </div>
            </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li style="display: block" class="table-row gambar-kosong">
                <div class="col" style="text-align: center; width: 100%;">
                    <img src="<?php echo e(asset('assets/dashboard/asset/img/tabel-kosong.svg')); ?>" alt="Kosong" />
                    <p>Anda belum memiliki mahasiswa bimbingan...</p>
                </div>
            </li>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div id="modal-profil" class="modal-overlay hidden">
    <div class="modal">
        <div class="modal-header">
            <h2>Informasi Mahasiswa</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="modal-content">
                <div class="profile-photo">
                    <!-- Gambar Profil Mahasiswa -->
                    <img src="<?php echo e(asset('assets/dashboard/asset/img/avatar.png')); ?>" alt="Foto Profil Mahasiswa" class="profil-img">
                </div>
                <div class="student-info">
                    <p><strong>Nama:</strong> Maulana Yusuf</p>
                    <p><strong>NIM:</strong> 4342401057</p>
                    <p><strong>Email:</strong> maulana@example.com</p>
                    <p><strong>No Telepon:</strong> 081234567890</p>
                    <p><strong>Judul Tugas Akhir:</strong> Pengembangan Aplikasi Jadwal Bimbingan</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/logbook.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/modal-logbook.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/logbook.blade.php ENDPATH**/ ?>