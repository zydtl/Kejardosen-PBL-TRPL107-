<header class="navbar">
    <!-- HAMBURGER BUTTON -->
    <button onclick="toggleSidebar()" class="toggle-button">&#9776;</button>
    <div class="navbar-right">
        <a data-jenis="dosen" id="logout"><i class="fi fi-br-power"></i></a>
        <a href="{{ route('dosen.profile') }}"><img src="{{asset('assets/dashboard/asset/img/avatar-dosen.png')}}" alt="User Profile" class="profile-icon" /></a>
    </div>
</header>