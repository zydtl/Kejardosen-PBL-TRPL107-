<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->yieldContent('css'); ?>
    <link rel="icon" href="<?php echo e(asset('assets/dashboard/asset/img/kejardosen-logo-circle.png')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.14.5/dist/sweetalert2.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
        rel="stylesheet">
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.6.0/uicons-solid-straight/css/uicons-solid-straight.css'>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel='stylesheet'
        href='https://cdn-uicons.flaticon.com/2.6.0/uicons-solid-straight/css/uicons-solid-straight.css'>

</head>

<body>

    <?php echo $__env->make('dashboard.admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="container">

        <!-- Sidebar -->
        <?php echo $__env->make('dashboard.admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Content -->
        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldContent('modalAdmin'); ?>


    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.14.5/dist/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/logout.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>

    <script>
        const logoutImageUrl = "<?php echo e(asset('assets/dashboard/asset/img/logout.png')); ?>";
    </script>



</body>

</html>
<?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/admin/layout/master.blade.php ENDPATH**/ ?>