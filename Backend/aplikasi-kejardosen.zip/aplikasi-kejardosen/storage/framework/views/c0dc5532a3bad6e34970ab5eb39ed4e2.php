<?php $__env->startSection('title'); ?>
    Dashboard - Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/Dashboard-dosen.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="left">
            <div class="card-welcome">
                <div class="text">
                    <h1>Halo!👋 </h1>
                    <div class="nama"><?php echo e($dosen->nama_dosen); ?></div>
                    <div class="slogan">🎯Bimbingan on time, Tugas Akhir on point!</div>
                    <a href="<?php echo e(route('dosen.waktu-dosen')); ?>">
                        <button  class="atur"><i class="fi fi-br-calendar"></i> <h3>Atur waktu Anda</h3></button>
                    </a>
                </div>
                <img class="img-welcome-dosen" src="<?php echo e(asset('assets/dashboard/asset/img/teacher_ilustration.png')); ?>" alt="" />
            </div>

            <div class="card-jadwal-dosen">
                <div class="weekly-schedule">
                    <i class="fi fi-br-calendar"></i>
                    <h3>Jadwal Dosen Pembimbing</h3>
                </div>
                <div class="schedule">
                    <div class="day <?php echo e($waktuDosen->kondisi_senin == 0 ? 'disabled' : ''); ?>">Sen</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_selasa == 0 ? 'disabled' : ''); ?>">Sel</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_rabu == 0 ? 'disabled' : ''); ?>">Rab</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_kamis == 0 ? 'disabled' : ''); ?>">Kam</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_jumat == 0 ? 'disabled' : ''); ?>">Jum</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_sabtu == 0 ? 'disabled' : ''); ?>">Sab</div>
                    <div class="day <?php echo e($waktuDosen->kondisi_minggu == 0 ? 'disabled' : ''); ?>">Min</div>
                </div>
            </div>

            <div class="info-cards">
                <div class="card-info">
                    <div class="card-info-icon">
                        <i class="fi fi-br-time-check"></i>
                    </div>
                    <div class="card-info-details">
                        <?php if($bimbinganBerlangsung > 0): ?>
                            <h4>0<?php echo e($bimbinganBerlangsung); ?></h4>
                        <?php else: ?>
                            <h4>00</h4>
                        <?php endif; ?>
                        <span>Bimbingan sedang berlangsung</span>
                    </div>
                </div>
                <div class="card-info">
                    <div class="card-info-icon">
                        <i class="fi fi-br-duration-alt"></i>
                    </div>
                    <div class="card-info-details">
                        <?php if($pengajuanMenunggu > 0): ?>
                            <h4>0<?php echo e($pengajuanMenunggu); ?></h4>
                        <?php else: ?>
                            <h4>00</h4>
                        <?php endif; ?>
                        <span>Menunggu Persetujuan Dosen</span>
                    </div>
                </div>
            </div>

            <div class="spacer"></div>
        </div>
        <div class="right">

            <h2 class="notif">🔔 Pemberitahuan</h2>

            
            <?php $__empty_1 = true; $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="notif-item">
                <div class="notif-icon 
                    <?php if($notif['type'] === 'Pengajuan Jadwal'): ?> blue 
                    <?php elseif($notif['type'] === 'Bimbingan Dibatalkan'): ?> red
                    <?php elseif($notif['type'] === 'Logbook'): ?> blue
                    <?php else: ?> gray <?php endif; ?>">
                    <i class="
                        <?php if($notif['type'] === 'Pengajuan Jadwal'): ?> fi fi-br-graduation-cap
                        <?php elseif($notif['type'] === 'Bimbingan Dibatalkan'): ?> fi fi-br-calendar
                        <?php elseif($notif['type'] === 'Logbook'): ?> fi fi-br-memo
                        <?php else: ?> fi fi-br-bell-slash <?php endif; ?>
                    "></i>
                </div>
                <div class="notif-text">
                    <h4><?php echo e($notif['type']); ?></h4>
                    <p><?php echo e($notif['mahasiswa']); ?> <?php echo e($notif['description']); ?></p>
                    <small class="date-text-notif" ><?php echo e(\Carbon\Carbon::parse($notif['updated_at'])->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y - H:i')); ?> WIB</small>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="notif-item">
                    <div class="notif-icon gray">
                        <i class="fi fi-br-bell-slash"></i>
                    </div>
                    <div class="notif-text">
                        <h4>Tidak Ada Notifikasi</h4>
                        <p>Anda tidak memiliki notifikasi dalam 7 hari terakhir.</p>
                    </div>
                </div>
            <?php endif; ?>
        

            <h2>📅 Jadwal Bimbingan</h2>

            <?php if($jadwal->isNotEmpty()): ?>
                <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bimbingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-pengajuan">
                        <a href="<?php echo e(route('dosen.detail-jadwal-bimbingan', ['kodeJadwal' => $bimbingan->kodeJadwal])); ?>">
                            <div class="detail1">
                                <div><img src="<?php echo e(asset('assets/dashboard/asset/img/avatar.png')); ?>" alt="" /></div>
                                <div class="value">
                                    <h4 class="dosen"><?php echo e($bimbingan->pengajuan->mahasiswa->nama_mahasiswa ?? 'Nama Mahasiswa'); ?></h4>
                                    <div class="tanggal">
                                        <i class="fi fi-br-calendar"></i> 
                                        <?php echo e(\Carbon\Carbon::parse($bimbingan->tanggal_bimbingan)->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y')); ?>

                                    </div>
                                    <div class="jam">
                                        <i class="fi fi-br-clock"></i> 
                                        <?php echo e(\Carbon\Carbon::parse($bimbingan->waktu_bimbingan)->format('H:i')); ?> WIB
                                    </div>
                                </div>
                            </div>
                        
                            <div class="detail2">
                                <div class="item">
                                    <i class="fi fi-br-map-marker-home"></i>
                                    <p>Ruangan</p>
                                    <span><?php echo e(strlen($bimbingan->tempat) > 24 ? 'Lihat selengkapnya  ➡️' : ($bimbingan->tempat ?? 'Tidak ada')); ?></span>
                                </div>
                                <div class="item">
                                    <i class="fi fi-br-time-add"></i>
                                    <p>Dibuat</p>
                                    <span>
                                        <?php echo e(\Carbon\Carbon::parse($bimbingan->created_at)->locale('id')->timezone('Asia/Jakarta')->translatedFormat('l, d F Y')); ?>

                                    </span>
                                </div>
                                <div class="item">
                                    <i class="fi fi-br-memo"></i>
                                    <p>Kode Pengajuan</p>
                                    <span><?php echo e($bimbingan->pengajuan->kodePengajuan ?? 'N/A'); ?></span>
                                </div>
                                <div class="item">
                                    <i class="fi fi-br-memo"></i>
                                    <p>Kode Jadwal</p>
                                    <span><?php echo e($bimbingan->kodeJadwal ?? 'N/A'); ?></span>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <img class="bimbingan-kosong" src="<?php echo e(asset('assets/dashboard/asset/img/bimbingan_kosong_dsn.svg')); ?>" alt="">
            <?php endif; ?>

            
            <div class="spacer"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/dashboard.blade.php ENDPATH**/ ?>