<?php $__env->startSection('title'); ?>
    Profil - Mahasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/profil.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="title">
            <h1>Profil Saya</h1>
        </div>
        <div class="profil">
            <div class="foto">
                <img class="foto-profil" src="<?php echo e(asset('assets/dashboard/asset/img/avatar.png')); ?>" alt="" />
            </div>
            <div class="identitas">
                <div class="title-identitas">
                    <h3>Informasi Pribadi</h3>
                </div>
                <div class="isi-identitas">
                    <div class="row">
                        <div class="left-column">
                            <div class="ket">Nama</div>
                            <div class="value"><?php echo e($mahasiswa->nama_mahasiswa); ?></div>

                            <div class="ket">NIM</div>
                            <div class="value"><?php echo e($mahasiswa->nim); ?></div>

                            <div class="ket">Kelas</div>
                            <div class="value"><?php echo e($mahasiswa->kelas); ?></div>
                        </div>
                        <div class="right-column">
                            <div class="ket">Email</div>
                            <div class="value"><?php echo e($mahasiswa->email); ?></div>

                            <div class="ket">Jenis Kelamin</div>
                            <div class="value"><?php echo e($mahasiswa->jenis_kelamin); ?></div>

                            <div class="ket">No Telp</div>
                            <div class="value"><?php echo e($mahasiswa->no_telp); ?></div>
                        </div>
                    </div>
                </div>
                <div class="title-tugas">
                    <h3>Informasi Tugas Akhir</h3>
                </div>
                <div class="isi-tugas">
                    <div class="row">
                        <div class="left-column">
                            <div class="ket">Judul Tugas Akhir</div>
                            <div class="value"><?php echo e($mahasiswa->judul_tugas_akhir); ?></div>

                            <div class="ket">Dosen Pembimbing</div>
                            <div class="value"><?php echo e($mahasiswa->dosen->nama_dosen); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.mahasiswa.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/mahasiswa/profile.blade.php ENDPATH**/ ?>