<?php $__env->startSection('title'); ?>
    Riwayat Pengajuan - Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/riwayat-pengajuan.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="title"><h1>Riwayat Pengajuan</h1></div>
        <div class="search-container">
            <input type="text" id="search-input" onkeyup="searchTable()" placeholder="Pencarian">
        </div>
        <ul class="responsive-table">
            <li class="table-header">
                <div class="col col-1">NIM Mahasiswa</div>
                <div class="col col-2">Diajukan Pada</div>
                <div class="col col-3">Tanggal Pengajuan</div>
                <div class="col col-4">Waktu Pengajuan</div>
                <div class="col col-5">Status</div>
                <div class="col col-6">Aksi</div>
            </li>

            <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="table-row">
                    <div class="col col-1" data-label="Kode Pengajuan"><?php echo e($item->nim); ?></div>
                    <div class="col col-2" data-label="Diajukan Pada"><?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('id')->timezone('Asia/Jakarta')->translatedFormat('d F Y - H:i')); ?> WIB</div>
                    <div class="col col-3" data-label="Tanggal Pengajuan"><?php echo e(\Carbon\Carbon::parse($item->tanggal_pengajuan)->translatedFormat('l, d F Y')); ?></div>
                    <div class="col col-4" data-label="Waktu Pengajuan"><?php echo e(\Carbon\Carbon::parse($item->waktu_pengajuan)->timezone('Asia/Jakarta')->format('H:i')); ?> WIB</div>
                    <div class="col col-5" data-label="Status">
                        <span
                            class="
                                <?php if($item->status == 'menunggu' || $item->status == 'alternatif'): ?>
                                    status-waiting
                                <?php elseif($item->status == 'dibatalkan' || $item->status == 'ditolak'): ?> 
                                    status-cancel
                                <?php elseif($item->status == 'diterima'): ?> 
                                    status-accept
                                <?php elseif($item->status == 'berlangsung'): ?> 
                                    status-ongoing
                                <?php elseif($item->status == 'disetujui'): ?> 
                                    status-accept                               
                                <?php elseif($item->status == 'diselesaikan'): ?> 
                                    status-finish 
                                <?php endif; ?>
                            "><?php echo e($item->status); ?>

                        </span>
                    </div>
                    <!-- <div class="col col-5" data-label="Status"><span class="status-reject">Ditolak</span></div> -->
                    <!-- <div class="col col-5" data-label="Status"><span class="status-resched">Reschedule</span></div> -->
                    <div class="col col-6" data-id="<?php echo e($item->kodePengajuan); ?>" data-label="Aksi">
                        <a href="<?php echo e(route('dosen.detail-riwayat-pengajuan', ['kodePengajuan' => $item->kodePengajuan])); ?>">
                            <i class="fi fi-br-info"></i>
                        </a>
                    </div>
                    
                    
                    
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="table-row gambar-kosong">
                    <div class="col" style="text-align: center; width: 100%;">
                        <img src="<?php echo e(asset('assets/dashboard/asset/img/tabel-kosong.svg')); ?>" alt="Kosong" />
                        <p>Belum ada riwayat jadwal bimbingan.</p>
                    </div>
                </li>
            <?php endif; ?> 
        </ul>
        <!-- Pagination -->
        <div class="pagination">
            <button class="prev-page">Prev</button>
            <span class="page-numbers">
                <span class="page-number active">1</span>
                <span class="page-number">2</span>
                <span class="page-number">3</span>
                <!-- Tambahkan lebih banyak page number sesuai dengan jumlah data -->
            </span>
            <button class="next-page">Next</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/riwayat.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dosen.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/dosen/riwayat-pengajuan.blade.php ENDPATH**/ ?>