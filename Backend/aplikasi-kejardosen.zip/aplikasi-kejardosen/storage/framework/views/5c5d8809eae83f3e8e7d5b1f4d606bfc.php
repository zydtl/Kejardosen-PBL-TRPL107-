<?php $__env->startSection('title'); ?>
    Waktu Dosen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/waktu-dosen.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/asset/css/sidebar-navbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="title">
        <h1>Waktu Dosen</h1>
    </div>
    <div class="card-info-dosen">
        <div class="foto-profil">
            <img src="<?php echo e(asset('assets/dashboard/asset/img/avatar-dosen.png')); ?>" alt="Foto Profil Dosen">
        </div>
        <div class="info">
            <h2><?php echo e($waktuDosen->dosen->nama_dosen); ?></h2>
            <p>NIK: <?php echo e($waktuDosen->dosen->nik); ?></p>
            <p>Email: <?php echo e($waktuDosen->dosen->email); ?></p>
            <p>No. Telp: +62 <?php echo e($waktuDosen->dosen->no_telp); ?></p>
            <span class="info-jadwal">Berikut adalah jadwal bimbingan yang telah diatur dosen selama satu minggu</span>
            <div class="contoh-warna">
                <div class="contoh-warna-aktif"></div> 
                <p>hari aktif</p>
                <div class="contoh-warna-tidak-aktif"></div>
                <p>hari tidak aktif</p>
            </div>
        </div>
        
    </div>
    
    
    <div class="card-hari">
        <div class="card-header">
            <div class="header-text">Jadwal <?php echo e($waktuDosen->dosen->nama_dosen); ?>:</div>
            <a href="<?php echo e(route('mahasiswa.pengajuan')); ?>" class="atur-jadwal-btn">Ajukan Jadwal</a>
            
        </div>
    
        <div class="hari <?php echo e($waktuDosen->kondisi_senin == 1 ? 'checked' : ''); ?>" id="kondisi-senin">
            <h3>Senin</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_selasa == 1 ? 'checked' : ''); ?>" id="kondisi-selasa">
            <h3>Selasa</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_rabu == 1 ? 'checked' : ''); ?>" id="kondisi-rabu">
            <h3>Rabu</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_kamis == 1 ? 'checked' : ''); ?>" id="kondisi-kamis">
            <h3>Kamis</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_jumat == 1 ? 'checked' : ''); ?>" id="kondisi-jumat">
            <h3>Jumat</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_sabtu == 1 ? 'checked' : ''); ?>" id="kondisi-sabtu">
            <h3>Sabtu</h3>
        </div>
        <div class="hari <?php echo e($waktuDosen->kondisi_minggu == 1 ? 'checked' : ''); ?>" id="kondisi-minggu">
            <h3>Minggu</h3>
        </div>
    </div>            
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/waktu-dosen.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/asset/javascript/sidebar-navbar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.mahasiswa.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/mahasiswa/waktu-dosen.blade.php ENDPATH**/ ?>