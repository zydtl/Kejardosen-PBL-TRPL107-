<header class="navbar">
    <!-- HAMBURGER BUTTON -->
    <button onclick="toggleSidebar()" class="toggle-button">&#9776;</button>
    <div class="navbar-right">
        <a data-jenis="admin" id="logout"><i class="fi fi-br-power"></i></a>
        <a><img src="<?php echo e(asset('assets/dashboard/asset/img/avatar-admin.jpg')); ?>" alt="User Profile" class="profile-icon" /></a>
    </div>
</header><?php /**PATH C:\PROJECT PBL\Github-kejardosen\Kejardosen-PBL-TRPL107-\Backend\aplikasi-kejardosen\resources\views/dashboard/admin/include/header.blade.php ENDPATH**/ ?>